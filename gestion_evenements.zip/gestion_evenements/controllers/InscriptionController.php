<?php
require_once __DIR__ . '/../models/InscriptionModel.php';
require_once __DIR__ . '/../models/EventModel.php';
require_once __DIR__ . '/../models/ParticipantModel.php';

class InscriptionController {
    private $model;

    public function __construct() {
        $this->model = new InscriptionModel();
    }

    public function inscrire($data) {
        if (!empty($data['event_id']) && !empty($data['participant_id'])) {
            return $this->model->inscrire($data['event_id'], $data['participant_id']);
        }
        return false;
    }

    public function getInscriptions() {
        return $this->model->getInscriptions();
    }
    public function afficherListe() {
        // Récupérer les inscriptions depuis le modèle
        $inscriptions = $this->getInscriptions();
        
        // Debug : Affiche les inscriptions dans le contrôleur pour vérifier
        //var_dump($inscriptions);
        
        // Vérifie que $inscriptions n'est pas null ou vide avant de l'inclure
        if (!empty($inscriptions)) {
            include '../views/inscriptions/list_inscriptions.php';
        } else {
            // Afficher un message si aucune inscription n'est trouvée
            echo "Aucune inscription trouvée.";
        }
    }
    
    
    
}
