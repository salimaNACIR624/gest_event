<?php
require_once __DIR__ . '/../models/EventModel.php';

class EventController {
    private $model;

    // Constructeur : Crée une instance du modèle EventModel
    public function __construct() {
        $this->model = new EventModel();  // Création de l'objet modèle pour interagir avec la base de données
    }

    // Méthode pour créer un événement
    public function handleCreate($data) {
        if (!empty($data['titre']) && !empty($data['date']) && !empty($data['description'])) {
            // Si les données sont valides, tente de créer l'événement via le modèle
            return $this->model->create($data['titre'], $data['date'], $data['description']);
        }
        // Si les données ne sont pas valides, retourne false
        return false;
    }

    // Méthode pour obtenir tous les événements
    public function getEvents() {
        return $this->model->getAll();  // Appelle la méthode getAll() du modèle pour récupérer tous les événements
    }

    // Méthode pour afficher la liste des événements
    public function afficherListe() {
        // Récupère la liste des événements à partir du modèle
        $events = $this->getEvents();

        // Vérifie si la liste des événements contient des données
        if ($events) {
            // Si des événements existent, inclut la vue pour les afficher
            include '../views/events/list_events.php';  // Assurez-vous que le chemin vers la vue est correct
        } else {
            // Si aucun événement n'est trouvé, affiche un message informatif
            echo "Aucun événement trouvé.";
        }
    }
}
?>
