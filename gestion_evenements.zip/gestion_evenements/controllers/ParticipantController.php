<?php
require_once __DIR__ . '/../models/ParticipantModel.php';

class ParticipantController {
    private $model;

    public function __construct() {
        $this->model = new ParticipantModel();
    }

    public function handleCreate($data) {
        if (!empty($data['nom']) && filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return $this->model->create($data['nom'], $data['email']);
        }
        return false;
    }

    public function getParticipants() {
        return $this->model->getAll();
    }
}
