<?php
// Inclure les modèles nécessaires
require_once __DIR__ . '/../../models/EventModel.php';

// Vérifier si l'ID de l'événement est passé dans l'URL
if (isset($_GET['id'])) {
    $eventId = $_GET['id'];

    // Créer une instance du modèle
    $eventModel = new EventModel();

    // Appeler la méthode pour récupérer l'événement par ID
    $event = $eventModel->getEventById($eventId);

    // Vérifier si l'événement a été trouvé
    if ($event) {
        // Utiliser les informations de l'événement (par exemple, les afficher dans un formulaire)
        // Par exemple, voici comment tu pourrais afficher le nom de l'événement dans un champ de formulaire :
        echo "<h2>Editer l'événement : " . htmlspecialchars($event['nom_evenement']) . "</h2>";
    } else {
        echo "<p>Événement introuvable.</p>";
    }
} else {
    echo "<p>ID de l'événement manquant.</p>";
}
?>
