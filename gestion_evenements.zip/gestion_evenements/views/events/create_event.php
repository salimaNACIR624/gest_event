<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un Événement</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen">
    <?php require_once __DIR__ . '/../../controllers/EventController.php'; 
    $controller = new EventController();
    $message = "";
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($controller->handleCreate($_POST)) {
            $message = "Événement ajouté avec succès.";
        } else {
            $message = "Erreur : tous les champs sont obligatoires.";
        }
    } ?>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-lg mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div class="bg-gradient-to-r from-blue-500 to-indigo-600 py-4 px-6">
                <h2 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-calendar-plus mr-3"></i>
                    Créer un Événement
                </h2>
            </div>
            
            <!-- Message de confirmation ou d'erreur -->
            <?php if ($message): ?>
                <div class="<?= strpos($message, 'succès') !== false ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?> px-4 py-3 my-4 mx-6 rounded-md">
                    <p class="flex items-center">
                        <i class="<?= strpos($message, 'succès') !== false ? 'fas fa-check-circle' : 'fas fa-exclamation-circle' ?> mr-2"></i>
                        <?= $message ?>
                    </p>
                </div>
            <?php endif; ?>
            
            <form method="post" class="p-6 space-y-6">
                <div class="space-y-2">
                    <label for="titre" class="block text-sm font-medium text-gray-700">Titre</label>
                    <input type="text" name="titre" id="titre" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                </div>
                
                <div class="space-y-2">
                    <label for="date" class="block text-sm font-medium text-gray-700">Date</label>
                    <input type="date" name="date" id="date" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition duration-200">
                </div>
                
                <div class="space-y-2">
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="description" id="description" rows="4" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 transition duration-200"></textarea>
                </div>
                
                <div class="flex items-center justify-between pt-4">
                    <a href="../index.php" class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 transition duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>Retour
                    </a>
                    <button type="submit" class="px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-medium rounded-md hover:from-blue-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200">
                        <i class="fas fa-plus mr-2"></i>Ajouter
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>