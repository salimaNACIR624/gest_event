<?php include __DIR__ . '/../layout/header.php'; ?>

<div class="container mx-auto p-6">
    <h1 class="text-2xl font-bold mb-4 text-center">Liste des événements</h1>

    <?php if (!empty($events)): ?>
        <table class="min-w-full bg-white border border-gray-300 rounded shadow">
            <thead class="bg-blue-500 text-white">
                <tr>
                    <th class="py-2 px-4 border">ID</th>
                    <th class="py-2 px-4 border">Titre</th>
                    <th class="py-2 px-4 border">Date</th>
                    <th class="py-2 px-4 border">Description</th>
                  
                </tr>
            </thead>
            <tbody>
                <?php foreach ($events as $event): ?>
                    <tr class="border-t">
                        <td class="py-2 px-4 border"><?= htmlspecialchars($event['id']) ?></td>
                        <td class="py-2 px-4 border"><?= htmlspecialchars($event['titre']) ?></td>
                        <td class="py-2 px-4 border"><?= htmlspecialchars($event['date_evenement']) ?></td>
                        <td class="py-2 px-4 border"><?= htmlspecialchars($event['description']) ?></td>
              
                    </tr>
                    
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucun événement trouvé.</p>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
