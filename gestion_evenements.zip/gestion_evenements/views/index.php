<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Événements</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <header class="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-lg p-6 mb-8">
            <h1 class="text-3xl font-bold text-white text-center">Accueil - Gestion des Événements</h1>
        </header>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <a href="events/create_event.php" class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center">
                <div class="bg-blue-100 p-4 rounded-full mb-4">
                    <i class="fas fa-calendar-plus text-blue-600 text-2xl"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-800">Créer un événement</h2>
                <p class="text-gray-600 mt-2 text-center">Ajoutez un nouvel événement au système</p>
            </a>
            
            <a href="participants/register_participant.php" class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center">
                <div class="bg-green-100 p-4 rounded-full mb-4">
                    <i class="fas fa-user-plus text-green-600 text-2xl"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-800">Inscrire un participant</h2>
                <p class="text-gray-600 mt-2 text-center">Enregistrez un nouveau participant</p>
            </a>
            
            <a href="inscriptions/register_inscription.php" class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center">
                <div class="bg-purple-100 p-4 rounded-full mb-4">
                    <i class="fas fa-clipboard-check text-purple-600 text-2xl"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-800">Inscrire à un événement</h2>
                <p class="text-gray-600 mt-2 text-center">Associez un participant à un événement</p>
            </a>
            
            <!-- Lien vers la liste des événements -->
            <a href="index.php?action=events" class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center">
                <div class="bg-yellow-100 p-4 rounded-full mb-4">
                    <i class="fas fa-calendar-alt text-yellow-600 text-2xl"></i>
                </div>
                <h2 class="text-xl font-semibold text-gray-800">Liste des événements</h2>
                <p class="text-gray-600 mt-2 text-center">Consultez tous les événements disponibles</p>
            </a>
            
            <a href="index.php?action=inscriptions" class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col items-center">
    <div class="bg-red-100 p-4 rounded-full mb-4">
        <i class="fas fa-list-alt text-red-600 text-2xl"></i>
    </div>
    <h2 class="text-xl font-semibold text-gray-800">Liste des inscriptions</h2>
    <p class="text-gray-600 mt-2 text-center">Voir toutes les inscriptions aux événements</p>
</a>

        </div>
    
    </div>

    <?php
    // Ajoute ici le code PHP pour gérer l'affichage des événements
    // Vérifie la route et appelle la méthode appropriée
    if (isset($_GET['action']) && $_GET['action'] === 'events') {
        // Appelle le contrôleur et la méthode pour afficher la liste des événements
        require_once __DIR__ . '/../controllers/EventController.php';
  // Modifie ici le chemin vers ton contrôleur

        $controller = new EventController();
        $controller->afficherListe(); // Affiche la liste des événements
    }
    ?>
    <?php
    

    // Pour la liste des inscriptions
    if (isset($_GET['action']) && $_GET['action'] === 'inscriptions') {
        // Appelle le contrôleur et la méthode pour afficher la liste des inscriptions
        require_once __DIR__ . '/../controllers/InscriptionController.php';
        $controller = new InscriptionController();
        $controller->afficherListe(); // Affiche la liste des inscriptions
    }
?>

</body>
</html>
