<?php if (!empty($inscriptions)): ?>
    <table class="min-w-full bg-white border border-gray-300 rounded shadow">
        <thead class="bg-blue-500 text-white">
            <tr>
                <th class="py-2 px-4 border">ID</th>
                <th class="py-2 px-4 border">Participant</th>
                <th class="py-2 px-4 border">Email</th>
                <th class="py-2 px-4 border">Événement</th>
                <th class="py-2 px-4 border">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($inscriptions as $inscription): ?>
                <tr class="border-t">
                    <td class="py-2 px-4 border"><?= htmlspecialchars($inscription['id']) ?></td>
                    <td class="py-2 px-4 border"><?= htmlspecialchars($inscription['nom_participant']) ?></td>
                    <td class="py-2 px-4 border"><?= htmlspecialchars($inscription['email']) ?></td>
                    <td class="py-2 px-4 border"><?= htmlspecialchars($inscription['nom_evenement']) ?></td>
                    <td class="py-2 px-4 border"><?= htmlspecialchars($inscription['date_inscription']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Aucune inscription trouvée.</p>
<?php endif; ?>
