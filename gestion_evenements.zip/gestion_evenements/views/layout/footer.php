<footer class="bg-gray-800 text-white text-center py-4 mt-8">
    <p>© 2025 Système de Gestion des Événements</p>
</footer>