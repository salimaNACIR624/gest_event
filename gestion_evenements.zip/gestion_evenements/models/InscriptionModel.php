<?php
require_once __DIR__ . '/../config/Database.php';

class InscriptionModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function inscrire($event_id, $participant_id) {
        $sql = "INSERT INTO inscriptions (event_id, participant_id, date_inscription) VALUES (?, ?, NOW())";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$event_id, $participant_id]);
    }

    public function getInscriptions() {
        $sql = "SELECT i.id, e.titre AS nom_evenement, p.nom AS nom_participant, p.email, i.date_inscription
                FROM inscriptions i
                JOIN events e ON i.event_id = e.id
                JOIN participants p ON i.participant_id = p.id";
        
        $stmt = $this->conn->query($sql);
        
        if (!$stmt) {
            echo "Erreur d'exécution de la requête : " . $this->conn->errorInfo()[2];
            return [];  // Retourne un tableau vide en cas d'erreur
        }
    
        // Vérifie si des données sont retournées
        $inscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        // Debug : Affiche les résultats
        //var_dump($inscriptions);  // Vérifie que des données sont récupérées
    
        return $inscriptions;
    }
    
    
    
    public function getAllInscriptions() {
        return $this->getInscriptions(); // tu peux aussi dupliquer si tu veux d'autres filtres
    }
    
}
