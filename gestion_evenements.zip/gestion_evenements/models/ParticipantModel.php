<?php
require_once __DIR__ . '/../config/Database.php';

class ParticipantModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function create($nom, $email) {
        $sql = "INSERT INTO participants (nom, email) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$nom, $email]);
    }

    public function getAll() {
        $sql = "SELECT * FROM participants";
        return $this->conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}
