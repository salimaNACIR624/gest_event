<?php
require_once __DIR__ . '/../config/Database.php';

class EventModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function create($titre, $date, $description) {
        $sql = "INSERT INTO events (titre, date_evenement, description) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$titre, $date, $description]);
    }

    public function getAll() {
        $sql = "SELECT * FROM events";
        return $this->conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getEventById($id) {
        // Préparer la requête SQL pour récupérer l'événement par son ID
        $query = "SELECT * FROM events WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        // Exécuter la requête
        $stmt->execute();

        // Vérifier si l'événement existe
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC); // Retourner l'événement
        }

        return null; // Retourner null si aucun événement n'est trouvé
    }
}
